// Vercel Function entry - all /api/*, /p/*.pdf and /health requests are rewritten here (see vercel.json)
module.exports = require('../server.js');
