-- Aavin milk app - Supabase schema. Run once in the Supabase SQL editor (or via migration).
-- The Node server talks to these tables with the service_role key only.
-- RLS is enabled with NO policies => anon / authenticated keys cannot read or write anything.

create table if not exists public.settings (
  id int primary key default 1 check (id = 1),
  v bigint not null default 0,
  admin_hash text,
  secret text,
  cfg jsonb not null default '{"anchor":"2026-10-01"}',
  ph_archive jsonb not null default '{}'
);
insert into public.settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.customers (
  id text primary key,
  name text not null,
  phone text not null,
  fi int, si int,
  ph text
);
create unique index if not exists customers_name_uq on public.customers (lower(name));
create unique index if not exists customers_phone_uq on public.customers (right(phone, 10));

create table if not exists public.milk_entries (
  id bigserial primary key,
  n text not null, d date not null, ss text not null default 'M',
  f text, s text, r numeric, q numeric, t numeric
);
create index if not exists milk_entries_n_d on public.milk_entries (n, d);

create table if not exists public.deductions (
  id bigserial primary key,
  n text not null, d date not null, l text, a numeric not null default 0, k text, pk text
);
create index if not exists deductions_n_d on public.deductions (n, d);

create table if not exists public.payouts (
  id bigserial primary key,
  key text not null, n text not null,
  q numeric, g numeric, b numeric, d numeric, net numeric, paid numeric, carry numeric,
  dt date, s int default 0, url text
);
create index if not exists payouts_n on public.payouts (n);

create table if not exists public.recycle_bin (
  id bigserial primary key,
  t text not null, at bigint, bb bigint, d jsonb
);

create table if not exists public.pdfs (
  id text primary key,
  data text not null,
  created_at timestamptz not null default now()
);
create index if not exists pdfs_created on public.pdfs (created_at);

alter table public.settings     enable row level security;
alter table public.customers    enable row level security;
alter table public.milk_entries enable row level security;
alter table public.deductions   enable row level security;
alter table public.payouts      enable row level security;
alter table public.recycle_bin  enable row level security;
alter table public.pdfs         enable row level security;

create or replace function public.get_state() returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'v', (select v from settings where id = 1),
    'cfg', (select cfg from settings where id = 1),
    'admin_hash', (select admin_hash from settings where id = 1),
    'secret', (select secret from settings where id = 1),
    'ph_archive', (select ph_archive from settings where id = 1),
    'cust', coalesce((select jsonb_agg(jsonb_build_object('id',id,'name',name,'phone',phone,'fi',fi,'si',si,'ph',ph) order by name) from customers), '[]'::jsonb),
    'items', coalesce((select jsonb_agg(jsonb_build_object('n',n,'d',d,'ss',ss,'f',f,'s',s,'r',r,'q',q,'t',t) order by id) from milk_entries), '[]'::jsonb),
    'deds', coalesce((select jsonb_agg(jsonb_strip_nulls(jsonb_build_object('n',n,'d',d,'l',l,'a',a,'k',k,'pk',pk)) order by id) from deductions), '[]'::jsonb),
    'pays', coalesce((select jsonb_agg(jsonb_strip_nulls(jsonb_build_object('key',key,'n',n,'q',q,'g',g,'b',b,'d',d,'net',net,'paid',paid,'carry',carry,'dt',dt,'s',s,'url',url)) order by id) from payouts), '[]'::jsonb),
    'bin', coalesce((select jsonb_agg(jsonb_strip_nulls(jsonb_build_object('t',t,'at',at,'bb',bb,'d',d)) order by id) from recycle_bin), '[]'::jsonb)
  );
$$;

create or replace function public.replace_state(p jsonb, expect bigint) returns jsonb
language plpgsql set search_path = public as $$
declare cur bigint;
begin
  select v into cur from settings where id = 1 for update;
  if expect is not null and cur <> expect then
    return jsonb_build_object('conflict', true, 'v', cur);
  end if;
  delete from customers where true;
  delete from milk_entries where true;
  delete from deductions where true;
  delete from payouts where true;
  delete from recycle_bin where true;
  insert into customers (id,name,phone,fi,si,ph)
    select id,name,phone,fi,si,ph from jsonb_to_recordset(coalesce(p->'cust','[]')) as x(id text,name text,phone text,fi int,si int,ph text);
  insert into milk_entries (n,d,ss,f,s,r,q,t)
    select n,d,ss,f,s,r,q,t from jsonb_to_recordset(coalesce(p->'items','[]')) as x(n text,d date,ss text,f text,s text,r numeric,q numeric,t numeric);
  insert into deductions (n,d,l,a,k,pk)
    select n,d,l,a,k,pk from jsonb_to_recordset(coalesce(p->'deds','[]')) as x(n text,d date,l text,a numeric,k text,pk text);
  insert into payouts (key,n,q,g,b,d,net,paid,carry,dt,s,url)
    select key,n,q,g,b,d,net,paid,carry,dt,s,url from jsonb_to_recordset(coalesce(p->'pays','[]')) as x(key text,n text,q numeric,g numeric,b numeric,d numeric,net numeric,paid numeric,carry numeric,dt date,s int,url text);
  insert into recycle_bin (t,at,bb,d)
    select t,at,bb,d from jsonb_to_recordset(coalesce(p->'bin','[]')) as x(t text,at bigint,bb bigint,d jsonb);
  update settings set v = cur + 1,
    cfg = coalesce(p->'cfg', cfg),
    ph_archive = coalesce(p->'ph_archive', ph_archive)
  where id = 1;
  return jsonb_build_object('conflict', false, 'v', cur + 1);
end $$;

-- only the server (service_role) may call these
revoke all on function public.get_state() from public, anon, authenticated;
revoke all on function public.replace_state(jsonb, bigint) from public, anon, authenticated;
grant execute on function public.get_state() to service_role;
grant execute on function public.replace_state(jsonb, bigint) to service_role;


-- ===== Token-guarded RPC wrappers (applied as migration "app_token_rpc") =====
-- Lets the server use the PUBLIC publishable key + a secret APP_DB_TOKEN instead of the service_role secret.
-- After creating the project run once (replace <TOKEN> with a long random string you also put in APP_DB_TOKEN):
--   update public.app_auth set token_hash = encode(extensions.digest(convert_to('<TOKEN>','utf8'),'sha256'),'hex') where id = 1;
create table if not exists public.app_auth (id int primary key default 1 check (id = 1), token_hash text);
alter table public.app_auth enable row level security;
insert into public.app_auth (id) values (1) on conflict (id) do nothing;
revoke all on public.app_auth from anon, authenticated;
create or replace function public.app_check(p_token text) returns void language plpgsql security definer set search_path = public, extensions as $$
declare h text;
begin
  select token_hash into h from public.app_auth where id = 1;
  if h is null or p_token is null or length(p_token) < 32 or h <> encode(extensions.digest(convert_to(p_token, 'utf8'), 'sha256'), 'hex') then
    raise exception 'forbidden' using errcode = '42501';
  end if;
end $$;
create or replace function public.app_state(p_token text) returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); return public.get_state(); end $$;
create or replace function public.app_replace(p_token text, p jsonb, expect bigint) returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); return public.replace_state(p, expect); end $$;
create or replace function public.app_set_admin(p_token text, p_hash text) returns void language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); update public.settings set admin_hash = p_hash where id = 1; end $$;
create or replace function public.app_init_secret(p_token text, p_secret text) returns void language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); update public.settings set secret = p_secret where id = 1 and secret is null; end $$;
create or replace function public.app_pdf_put(p_token text, p_id text, p_data text) returns void language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); insert into public.pdfs (id, data) values (p_id, p_data); end $$;
create or replace function public.app_pdf_get(p_token text, p_id text) returns text language plpgsql security definer set search_path = public, extensions as $$
declare d text;
begin perform public.app_check(p_token); select data into d from public.pdfs where id = p_id; return d; end $$;
create or replace function public.app_pdf_cleanup(p_token text) returns void language plpgsql security definer set search_path = public, extensions as $$
begin perform public.app_check(p_token); delete from public.pdfs where created_at < now() - interval '90 days'; end $$;
revoke all on function public.app_check(text) from public, anon, authenticated;
revoke all on function public.app_state(text), public.app_replace(text, jsonb, bigint), public.app_set_admin(text, text), public.app_init_secret(text, text), public.app_pdf_put(text, text, text), public.app_pdf_get(text, text), public.app_pdf_cleanup(text) from public;
grant execute on function public.app_state(text), public.app_replace(text, jsonb, bigint), public.app_set_admin(text, text), public.app_init_secret(text, text), public.app_pdf_put(text, text, text), public.app_pdf_get(text, text), public.app_pdf_cleanup(text) to anon, authenticated, service_role;
