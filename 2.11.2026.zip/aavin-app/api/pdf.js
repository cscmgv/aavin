// Vercel Function: public PDF links. vercel.json rewrites /p/<id>.pdf -> /api/pdf?id=<id>.pdf
module.exports = require('../server.js');
