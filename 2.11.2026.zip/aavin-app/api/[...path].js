// Vercel Function: handles every /api/* request (req.url keeps the real path, e.g. /api/login)
module.exports = require('../server.js');
